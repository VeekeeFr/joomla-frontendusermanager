if(hepta === undefined) {
  var hepta = {};
}

hepta.dzfield = {};

function dzSuccessfulUpload(file, responseText, containerId)
{
	console.log(responseText);

	var filesContainer = hepta.dzfield[containerId];

	responseText = JSON.parse(responseText);
	if(responseText.error == 0)
	{
		while(responseText.uploadedFiles.length)
		{
			var uploadedFile = responseText.uploadedFiles.pop();
			var fileHash =  uploadedFile.hash;
			file.hash = fileHash;
			uploadedFile.id = 0;
			filesContainer.dzFiles.push({'id': uploadedFile.id.toString(), 'name': uploadedFile.name.toString(), 'path': uploadedFile.path.toString(), 'hash': fileHash});
		}
		jQuery('#' + responseText.fieldId).val(JSON.stringify(filesContainer.dzFiles));
	}
}

function dzRemoveFile(file,containerId)
{
	var toRemove = file.hash;
	var filesContainer = hepta.dzfield[containerId];

	delete filesContainer.dzFiles[toRemove];

    for(i=0; i < filesContainer.dzFiles.length; i++)
    {
        if(filesContainer.dzFiles[i].hash == file.hash)
        {
            filesContainer.dzFiles.splice(i,1);
            break;
        }
    }

	hepta.Dropzone[containerId].options.maxFiles = hepta.Dropzone[containerId].options.maxFilesReference  - filesContainer.dzFiles.length;

	jQuery('#' + containerId).val(JSON.stringify(filesContainer.dzFiles));
}

function addServerFile(containerId, dzFile)
{
	var imageUrl = encodeURI(hepta.baseURL + dzFile.path);

	hepta.Dropzone[containerId].emit("addedfile", dzFile);
	hepta.Dropzone[containerId].emit("thumbnail", dzFile, imageUrl);

	hepta.Dropzone[containerId].createThumbnailFromUrl(dzFile, imageUrl);

	// Make sure that there is no progress bar, etc...
	hepta.Dropzone[containerId].emit("complete", dzFile);
}

function addServerFiles(containerId) {

	var value = jQuery('#' + containerId).val();

	if(value !== "")
	{
		var files = JSON.parse(value);

		if(files != null && typeof files.length != undefined)
		{

			jQuery.each(files,function (index, dzFile) {
				addServerFile(containerId, dzFile);
			});
			var existingFileCount = files.length; // The number of files already uploaded
			hepta.Dropzone[containerId].options.maxFiles = hepta.Dropzone[containerId].options.maxFiles - existingFileCount;
		}
	}
};
