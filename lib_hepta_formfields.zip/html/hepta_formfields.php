<?php
/**
 * @package     Sample.Library
 * @subpackage  Html
 *
 * @copyright   Copyright (C) 2013 Roberto Segura. All rights reserved.
 * @license     GNU General Public License version 2 or later, see LICENSE.
 */

defined('_JEXEC') or die;

/**
 * Html css class.
 *
 * @package     Hepta Form Fields.Library
 * @subpackage  Html
 * @since       1.0
 */
abstract class JHtmlHepta_formfields
{
	/**
	 * Extension name to use in the asset calls
	 * Basically the media/com_xxxxx folder to use
	 */
	const EXTENSION = 'hepta';
}
