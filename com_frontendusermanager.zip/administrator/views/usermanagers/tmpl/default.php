<?php
defined('_JEXEC') or die;
?>

<div class="alert warning text-center">
  <?php echo JText::_('COM_FRONTENDUSERMANAGER_CPANEL_INFO'); ?>
</div>
