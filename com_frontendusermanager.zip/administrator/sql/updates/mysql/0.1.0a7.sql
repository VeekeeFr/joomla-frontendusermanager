ALTER TABLE `#__frontendusermanager_criterias`
MODIFY `excludedFields` TEXT;
