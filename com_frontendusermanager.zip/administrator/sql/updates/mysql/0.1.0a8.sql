ALTER TABLE `#__frontendusermanager_criterias`
ADD COLUMN `excludedUsers` VARCHAR(255) NOT NULL AFTER `profilefields`;
