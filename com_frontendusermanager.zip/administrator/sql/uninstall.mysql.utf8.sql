DROP TABLE IF EXISTS `#__frontendusermanager_criterias`;
